<?php

namespace App\Http\Controllers\Games\SpinData\FortuneOX;

class FortuneOXBonus
{
    /**
     * @return array
     */
    public static function getBonus(): array
    {
        return [];
    }
}
