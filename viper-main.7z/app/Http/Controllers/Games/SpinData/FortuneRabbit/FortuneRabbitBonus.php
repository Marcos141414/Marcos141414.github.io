<?php

namespace App\Http\Controllers\Games\SpinData\FortuneRabbit;

class FortuneRabbitBonus
{
    /**
     * @return array
     */
    public static function getBonus(): array
    {
        return [];
    }
}
