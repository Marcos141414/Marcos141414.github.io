<?php

namespace App\Http\Controllers\Games\SpinData\FortuneTiger;

class FortuneTigerDemo
{
    /**
     * @return array
     */
    public static function getDemo(): array
    {
        return [];
    }
}
