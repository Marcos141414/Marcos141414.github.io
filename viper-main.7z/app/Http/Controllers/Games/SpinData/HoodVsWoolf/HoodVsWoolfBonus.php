<?php

namespace App\Http\Controllers\Games\SpinData\HoodVsWoolf;

class HoodVsWoolfBonus
{
    /**
     * @return array
     */
    public static function getBonus(): array
    {
        return [];
    }
}
