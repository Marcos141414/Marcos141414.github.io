<?php

namespace App\Http\Controllers\Games\SpinData\JackFrost;

class JackFrostBonus
{
    /**
     * @return array
     */
    public static function getBonus(): array
    {
        return [];
    }
}
