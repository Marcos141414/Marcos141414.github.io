<?php

namespace App\Services\Gateways;

class StripeService
{

}
