<?php

namespace App\Enums;

class UserStatus
{
    const ACTIVE = 'active';
    const BANNED = 'banned';
    const PENDING_APPROVAL = 'pending_approval';
    const INACTIVE = 'inactive';


}
