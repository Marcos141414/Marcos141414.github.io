<?php

namespace App\Filament\Resources\FiversGameResource\Pages;

use App\Filament\Resources\FiversGameResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateFiversGame extends CreateRecord
{
    protected static string $resource = FiversGameResource::class;
}
