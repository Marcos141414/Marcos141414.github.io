<?php

namespace App\Http\Controllers\Games\SpinData\FortuneMouse;

class FortuneMouseBonus
{
    /**
     * @return array
     */
    public static function getBonus(): array
    {
        return [];
    }
}
