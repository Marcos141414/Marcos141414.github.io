<?php

namespace App\Http\Controllers\Games\SpinData\FortunePanda;

class FortunePandaBonus
{
    /**
     * @return array
     */
    public static function getBonus(): array
    {
        return [];
    }
}
