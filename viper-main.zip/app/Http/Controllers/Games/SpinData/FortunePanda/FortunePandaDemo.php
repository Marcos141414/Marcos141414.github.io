<?php

namespace App\Http\Controllers\Games\SpinData\FortunePanda;

class FortunePandaDemo
{
    /**
     * @return array
     */
    public static function getDemo(): array
    {
        return [];
    }
}
