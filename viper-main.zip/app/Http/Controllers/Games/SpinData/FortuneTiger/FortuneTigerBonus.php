<?php

namespace App\Http\Controllers\Games\SpinData\FortuneTiger;

class FortuneTigerBonus
{
    /**
     * @return array
     */
    public static function getBonus(): array
    {
        return [];
    }
}
