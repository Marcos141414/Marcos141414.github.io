<?php

namespace App\Http\Controllers\Games\SpinData\HoodVsWoolf;

class HoodVsWoolfDemo
{
    /**
     * @return array
     */
    public static function getDemo(): array
    {
        return [];
    }
}
