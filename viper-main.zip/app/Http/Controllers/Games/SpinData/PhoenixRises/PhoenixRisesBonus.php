<?php

namespace App\Http\Controllers\Games\SpinData\PhoenixRises;

class PhoenixRisesBonus
{
    /**
     * @return array
     */
    public static function getBonus(): array
    {
        return [];
    }
}
