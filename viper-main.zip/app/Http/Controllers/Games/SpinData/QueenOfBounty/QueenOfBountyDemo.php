<?php

namespace App\Http\Controllers\Games\SpinData\QueenOfBounty;

class QueenOfBountyDemo
{
    /**
     * @return array[]
     */
    public static function getDemo(): array
    {
        return [];
    }
}
