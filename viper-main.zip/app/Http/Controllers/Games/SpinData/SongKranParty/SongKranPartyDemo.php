<?php

namespace App\Http\Controllers\Games\SpinData\SongKranParty;

class SongKranPartyDemo
{
    /**
     * @return array[]
     */
    public static function getDemo(): array
    {
        return [];
    }
}
