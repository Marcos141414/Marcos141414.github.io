<?php

namespace App\Http\Controllers\Games\SpinData\TreasuresOfAztec;

class TreasuresOfAztecDemo
{
    /**
     * @return array[]
     */
    public static function getDemo(): array
    {
        return [];
    }
}
