<?php


return [
    'list_user' => 'Lista de Usuários',
    'view_user' => 'Ver Usuário',
    'edit_user' => 'Editar Usuário',
    'change_password' => 'Mudar Senha',
    'demo' => 'Demo',
    'demo' => 'Demo',
    'demo' => 'Demo',
    'demo' => 'Demo',
    'demo' => 'Demo',
    'demo' => 'Demo',
    'demo' => 'Demo',
    'demo' => 'Demo',
    'demo' => 'Demo',
    'demo' => 'Demo',
    'demo' => 'Demo',
    'demo' => 'Demo',
    'demo' => 'Demo',
];
